__author__="huziy"
__date__ ="$13 juil. 2010 16:27:16$"


class Variable():
    '''
    Contains variable data at specific point
    '''
    def __init__(self, geopoint, value):
        self.geopoint = geopoint
        self.value = value
        pass


if __name__ == "__main__":
    print "Hello World"
