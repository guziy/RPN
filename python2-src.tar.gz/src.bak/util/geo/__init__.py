__author__="huziy"
__date__ ="$13 juil. 2010 13:34:33$"