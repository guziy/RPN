__author__ = 'huziy'

import numpy as np

#create shape file of north america without Greenland

def read_na_geometry(path = "data/shp/continents/continent.shp"):
    pass

def main():
    #TODO: implement
    pass

if __name__ == "__main__":
    main()
    print "Hello world"
  