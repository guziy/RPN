__author__="huziy"
__date__ ="$Aug 19, 2011 3:27:17 PM$"

binary_transparent = 0
floating_point = 1
unsigned_integer = 2
character = 3
signed_integer = 4
IEEE_floating_point = 5
floating_point_16_bit = 6
character_string = 7
complex_IEEE = 8
compressed_short_integer = 130
compressed_IEEE = 133
compressed_floating_point = 134


if __name__ == "__main__":
    print "Hello World"
