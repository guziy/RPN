__author__ = 'huziy'

import numpy as np

class ProjParams:
    def __init__(self):
        pass



def main():
    #TODO: implement
    pass

if __name__ == "__main__":
    main()
    print "Hello world"
  