__author__ = 'huziy'

def init():
    pass


def update(*args):
    pass


def main():
    pass


if __name__ == "__main__":
    main()