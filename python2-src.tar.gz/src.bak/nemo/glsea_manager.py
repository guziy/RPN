__author__ = 'huziy'



class GlseaDataManager(object):

    def __init__(self):
        pass

    def get_seasonal_means(self, season_name_to_months = None,
                           start_year = None, end_year = None):
        #TODO: implement
        pass

    def get_area_average(self):
        pass