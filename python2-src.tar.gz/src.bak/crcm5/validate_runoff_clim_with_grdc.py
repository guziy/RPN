__author__ = 'huziy'

import numpy as np



def plot_diff_for_the_simulation(simName, simPath,ax):
    """
    plot as a subplot tot_runoff_sim - tot_runoff_grdc(interpolated to the model grid)
    """


    pass










def main():
    #TODO: implement
    pass

if __name__ == "__main__":
    main()
    print "Hello world"
  