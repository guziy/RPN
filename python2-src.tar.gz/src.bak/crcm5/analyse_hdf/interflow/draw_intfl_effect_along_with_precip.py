__author__ = 'huziy'

# Map in the center divided into 9 regions
# select a point from 8 of those regions (excluding the central part) (maybe select the point with max deltaR)

def main():
    pass




if __name__ == '__main__':
    main()