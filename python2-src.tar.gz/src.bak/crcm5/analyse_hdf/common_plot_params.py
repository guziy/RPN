__author__ = 'huziy'

import numpy as np

COASTLINE_WIDTH = 0.2

FIG_SAVE_DPI = 800

def main():
    #TODO: implement
    pass

if __name__ == "__main__":
    main()
    print "Hello world"
  