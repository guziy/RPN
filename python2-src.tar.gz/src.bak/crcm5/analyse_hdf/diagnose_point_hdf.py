__author__ = 'huziy'



def main():

    #TODO get CEHQ station data

    #TODO: get HYDAT station data

    pass



if __name__ == "__main__":
    main()
