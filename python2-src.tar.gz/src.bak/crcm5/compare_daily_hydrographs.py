__author__ = 'huziy'

import numpy as np



def find_closest_gridcells(stations):
    pass



def export_timeseries_to_netcdf():
    pass





def main():




    pass

if __name__ == "__main__":
    main()
    print "Hello world"
  