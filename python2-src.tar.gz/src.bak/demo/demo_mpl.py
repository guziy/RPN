__author__ = 'huziy'

import numpy as np
import matplotlib as mpl

def main():
    print mpl.__version__
    print mpl.get_backend()
    pass

if __name__ == "__main__":
    main()
    print "Hello world"
  