__author__ = 'huziy'

import numpy as np

def main():
    import netCDF4

    print netCDF4.__version__
    pass

if __name__ == "__main__":
    main()
    print "Hello world"
  